# Sonora 🎵

Tu reproductor de música personal. PWA instalable desde Chrome.

## Cómo subir a GitHub Pages

1. Crea un repositorio nuevo en GitHub (ej: `sonora`)
2. Sube estos archivos: `index.html`, `manifest.json`, `sw.js`, `icon.svg`
3. Ve a **Settings → Pages → Source → main branch / root**
4. GitHub te dará una URL tipo `https://tuusuario.github.io/sonora`
5. Abre esa URL en Chrome → aparece un botón **"Instalar"** en la barra de direcciones
6. Instala → tienes Sonora como app con su propio icono

## Características

- 🎵 Carga más de 200 MP3 a la vez
- 🖼 Lee metadatos: portada, artista, álbum, año, género
- 🎨 Paleta de colores dinámica según la portada
- 💾 **Todo se guarda automáticamente** (IndexedDB — sin límite de tamaño)
- 📋 Listas de reproducción ilimitadas
- 🔍 Búsqueda en tiempo real
- ❤️ Sistema de Me gusta
- 🔀 Modo aleatorio y repetición
- 🖥 Vista a pantalla completa (clic en la portada del player)
- ⌨️ Atajos: `Space` play/pausa, `Alt+→/←` siguiente/anterior, `Esc` cierra pantalla completa
